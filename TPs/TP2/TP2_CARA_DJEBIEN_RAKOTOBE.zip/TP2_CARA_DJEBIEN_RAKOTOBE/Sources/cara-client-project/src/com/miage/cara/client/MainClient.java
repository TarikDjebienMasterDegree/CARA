package com.miage.cara.client;
import com.miage.client.view.IHM;

/**
 * @author tarik
 * @author Eric
 */
public class MainClient {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		//Création de notre client
		new IHM();
	}

}

