package com.miage.entity;
import java.io.Serializable;
import java.util.Collection;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToMany;
import javax.persistence.ManyToOne;

/**
 * Entity implementation class for Entity: Article
 * @author tarik
 * @author Eric
 */
@Entity
public class Article implements Serializable {

	   
	private static final long serialVersionUID = 2L;
	
	
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	@Column(name="ARTICLE_ID")
	private Long id;
	private String description;
	private Float prixVente;
	private Float montantDerniereEnchere;
	
	@ManyToOne(fetch=FetchType.EAGER)
	private Utilisateur vendeur ; 
	
	@ManyToOne(fetch=FetchType.EAGER)
	private Utilisateur acheteur ; 
	
	@ManyToMany(mappedBy="articlesObservees")
	private Collection<Utilisateur> utilisateursObserveurs ;  

	public Article() {}

	/**
	 * @return the id
	 */
	public Long getId() {
		return id;
	}

	/**
	 * @param id the id to set
	 */
	public void setId(Long id) {
		this.id = id;
	}

	/**
	 * @return the description
	 */
	public String getDescription() {
		return description;
	}

	/**
	 * @param description the description to set
	 */
	public void setDescription(String description) {
		this.description = description;
	}

	/**
	 * @return the prixVente
	 */
	public Float getPrixVente() {
		return prixVente;
	}

	/**
	 * @param prixVente the prixVente to set
	 */
	public void setPrixVente(Float prixVente) {
		this.prixVente = prixVente;
	}

	/**
	 * @return the montantDerniereEnchere
	 */
	public Float getMontantDerniereEnchere() {
		return montantDerniereEnchere;
	}

	/**
	 * @param montantDerniereEnchere the montantDerniereEnchere to set
	 */
	public void setMontantDerniereEnchere(Float montantDerniereEnchere) {
		this.montantDerniereEnchere = montantDerniereEnchere;
	}

	/**
	 * @return the vendeur
	 */
	public Utilisateur getVendeur() {
		return vendeur;
	}

	/**
	 * @param vendeur the vendeur to set
	 */
	public void setVendeur(Utilisateur vendeur) {
		this.vendeur = vendeur;
	}

	/**
	 * @return the acheteur
	 */
	public Utilisateur getAcheteur() {
		return acheteur;
	}

	/**
	 * @param acheteur the acheteur to set
	 */
	public void setAcheteur(Utilisateur acheteur) {
		this.acheteur = acheteur;
	}

	
	
	
	/**
	 * @return the utilisateursObserveurs
	 */
	public Collection<Utilisateur> getUtilisateursObserveurs() {
		return utilisateursObserveurs;
	}

	/**
	 * @param utilisateursObserveurs the utilisateursObserveurs to set
	 */
	public void setUtilisateursObserveurs(
			Collection<Utilisateur> utilisateursObserveurs) {
		this.utilisateursObserveurs = utilisateursObserveurs;
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "Article [id=" + id + ", description=" + description + "]";
	}   
	
}
