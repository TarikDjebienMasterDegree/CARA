package com.miage.ejb;

import javax.ejb.Remote;

import com.miage.ejb.exception.UserAlreadyExistException;
import com.miage.ejb.exception.UserBadLoginException;
import com.miage.entity.Utilisateur;

/**
 * Interface pour les services sur les utilisateurs
 * @author tarik
 * @author Eric
 */
@Remote
public interface IUtilisateurServiceRemote {

	/**
	 * Un utilisateur peut sâ€™inscrire auprÃ¨s de la salle des ventes aux enchÃ¨res. 
	 * Pour cela, il doit se connecter Ã  la salle et fournir son nom, son adresse postale, 
	 * son adresse Ã©lectronique ainsi quâ€™un mot de passe. 
	 * La salle des ventes doit vÃ©riï¬�er quâ€™il nâ€™existe pas deux utilisateurs ayant le mÃªme nom.
	 * 
	 * @param nom
	 * @param adresse
	 * @param mail
	 * @param password
	 * @return
	 * @throws UserAlreadyExistException
	 */
	Utilisateur inscrire(String nom, String adresse, String mail, String password) throws UserAlreadyExistException;
	
	/**
	 * Un utilisateur doit s'identiï¬�er auprÃ¨s de la salle des ventes pour pouvoir vendre ou acheter des articles. 
	 * Pour cela, lâ€™application de lâ€™utilisateur envoie son nom et son mot de passe qui sont alors vÃ©riï¬�Ã©s 
	 * par la salle. Si le nom et/ou le mot de passe sont incorrects, une erreur est retournÃ©e Ã  lâ€™application 
	 * cliente sinon une rÃ©fÃ©rence sur lâ€™objet reprÃ©sentant lâ€™utilisateur au sein du serveur de la salle 
	 * des ventes est retournÃ©e. Cet objet permet alors Ã  lâ€™utilisateur de proposer des articles Ã  la 
	 * vente ou des enchÃ¨res sur des articles en vente.
	 * 
	 * @param nom
	 * @param password
	 * @return
	 * @throws UserBadLoginException
	 */
	Utilisateur identifier(String nom, String password) throws UserBadLoginException;
	
	
	/**
	 * AprÃ¨s s'Ãªtre identifiÃ©, un utilisateur peut consulter la liste des articles en cours de vente, 
	 * en sÃ©lectionner un, consulter
	 * lâ€™enchÃ¨re courante et proposer une nouvelle enchÃ¨re. 
	 * La salle des ventes vÃ©rifiera que le montant de lâ€™enchÃ¨re proposÃ©e est supÃ©rieur `Ã  la derniÃ¨re enchÃ¨re 
	 * (ou au montant minimal dÃ©sirÃ© par le vendeur. Si le montant est incorrect alors une erreur est
	 * retournÃ©e sinon la salle mÃ©morise que tel acheteur a proposÃ© tel montant pour lâ€™article.
	 * @param nomAcheteur
	 * @param idArticle
	 */
	void surrencherir(String nomAcheteur, Long idArticle , Float montantDerniereEnchere) ;	
	
	
	/**
	 * Lorsque le vendeur d’un article considère que le prix atteint par lui convient alors, 
	 * après s'être identifié, il signale à la salle
	 * des ventes que la vente de l’article est close. La salle des ventes envoie alors au vendeur 
	 * les références complètes de l’acheteur. 
	 * Ces deux utilisateurs concluent réellement la vente par un moyen non virtuel. 
	 * L’article est alors retiré de la salle des ventes.
	 * @return le vendeur
	 */
	Utilisateur cloturerVente(Long idArticle) ;	
	
	
}
