package com.miage.ejb;
import java.util.List;

import javax.ejb.Remote;

import com.miage.entity.Article;
import com.miage.entity.Utilisateur;

/**
 * Interface pour les services sur les articles
 * @author tarik
 * @author Eric
 */
@Remote
public interface IArticleServiceRemote {

	/**
	 * 
	 * Proposition d’un article à la vente
	 * Après s'être identifié, un utilisateur peut proposer un article à la vente. 
	 * L’article est alors décrit par un texte et un montant
	 * minimal de vente. En retour, la salle des ventes crée un objet article, 
	 * lui associe un identifiant unique et conserve le lien entre
	 * l’utilisateur vendeur et l’article mis à la vente.
	 * Proposition d’une enchère
	 * @param description
	 * @param prixVente
	 * @return
	 */
	Article ajouterArticle(String nomVendeur, String description, Float prixVente);
	
	
	/**
	 * Recupere tous les articles mis en vente
	 * @return la liste des articles
	 */
	List<Article> getAllArticlesEnVente();	
	
	
	/**
	 * Recupere la liste des articles mis en
	 * vente par l'utiisateur en parametre
	 * @return la liste des articles mis en vente par l'user
	 */
	List<Article> getAllArticlesMisEnVente(Utilisateur u);	
	
	
	/**
	 * Recupere un article par son id
	 */
	Article findArticleById(Long idArticle);	
	
	
	/**
	 * Methode permettant de souscrire un article
	 * pour un acheteur
	 */
	void souscrireArticle(Long idArticle, String nomAcheteur);
	
	
	
	/**
	 * Methode permettant de tester si l'acheteur s'est bien
	 * inscris sur la vente aux encheres de cet article
	 */
	boolean verifierAcheteursSouscription(Long idArticle, String nomAcheteur);
		
	
}
