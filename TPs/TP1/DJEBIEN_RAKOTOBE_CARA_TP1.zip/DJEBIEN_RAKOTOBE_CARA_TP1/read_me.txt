

	******************************************
	*	CARA TP1 : TP Web Services	 *
	*	M2 FA MIAGE			 *
	*	DJEBIEN TARIK			 *
	*	RAKOTOBE ERIC		         *
	******************************************


Ce fichier est un fichier readme pour le tp1 de CARA,
de la formation MIAGE en alternance, 2�me ann�e.


Le tp a �t� r�alis� en bin�me dont les auteurs sont :
- TARIK Djebien
- RAKOTOBE Eric


Tout ce qui a �t� propos� dans le TP a �t� fait.


Dans cette archive fournie, on retrouve 3 fichiers :
	- le fichier read_me.txt ci-ouvert
	- un 'tutoriel' expliquant en d�tail comment le TP a �t� r�alis�.
	- le code source du TP.


Dans le code source du tp, on retrouve :
	- Les tests unitaires r�dig�s pour tester les diff�rentes m�thodes 
	dans : Axis2WebServices\src\com\client\test

	- les diff�rents webservices d�velopp�s, ainsi que les stubs et handlers
	autog�n�r�s par Eclipse/Axis2
	dans : Axis2WebServices\src\com\webservices


Si vous avez des questions compl�mentaires, veuillez contacter les auteurs par mail : 

tarik.djebien@etudiant.univ-lille1.fr
se.rakotobe@etudiant.univ-lille1.fr